# MAX RADIUS 2.7.0: MariaDB memory configuration

This directory ships with the Web image at /opt/max-deploy/2.7.0/db-memory.
It is configuration material, not an automatic database installer or migration.

balanced: set MALLOC_ARENA_MAX=2 on the verified glibc MariaDB engine and preserve existing caches.
conservative: balanced plus Aria=16MiB and key buffer=8MiB, only after target-load qualification.
Neither profile changes InnoDB buffers, durability, application tables, licenses, or the database engine version.

The Compose examples target a service called mariadb. They do not automatically apply to the native
max-r host pools max-db-a/max-db-b. The operator must resolve ownership, all dependent tenants,
current image digest/version/allocator, existing options and mounts before producing a per-host plan.
Do not replace a pinned image reference with latest or a floating tag.
Do not grant a tenant Web control over a shared database engine.

Changing MALLOC_ARENA_MAX on an existing container requires recreating that container with its
same storage, credentials, networks and approved image. Plan SQL unavailability for all affected tenants.
Retain the previous container/configuration, and verify recovery with real RADIUS/accounting evidence.
Reverting application containers does not require restoring an old database backup over newer writes.

No profile is auto-enabled by the Web entrypoint. The core application image does not apply these files.
Host/panel integration for native max-r labels remains a separate acceptance gate before Hetzner cutover.
